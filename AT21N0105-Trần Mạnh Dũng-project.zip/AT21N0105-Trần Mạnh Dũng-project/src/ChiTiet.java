import java.sql.Date;

/** Một dòng trong khung chi tiết: khách hàng + thông tin lần mua xe. */
public class ChiTiet {
    public String maKH;
    public String tenKH;
    public String cmnd;   // đúng 12 chữ số (giữ số 0 đầu)
    public String gioiTinh;
    public String diaChi;
    public String maXe;
    public Date ngayMua;
    public int soLuong;
    public String ghiChu;
}
