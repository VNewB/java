public class Xe {
    public String maXe;
    public String tenXe;
    public int dungTich;
    public int donGia;

    public Xe(String maXe, String tenXe, int dungTich, int donGia) {
        this.maXe = maXe;
        this.tenXe = tenXe;
        this.dungTich = dungTich;
        this.donGia = donGia;
    }
}
