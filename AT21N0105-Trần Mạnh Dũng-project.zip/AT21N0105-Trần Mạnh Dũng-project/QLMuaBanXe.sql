-- Chạy bằng SQL Server Management Studio
IF DB_ID('QLMuaBanXe') IS NULL CREATE DATABASE QLMuaBanXe;
GO
USE QLMuaBanXe;
GO
-- Xóa bảng cũ (kiểu INT) để tạo lại với mã dạng chuỗi. CẢNH BÁO: mất dữ liệu cũ.
DROP TABLE IF EXISTS Mua_Xe;
DROP TABLE IF EXISTS Khach_Hang;
DROP TABLE IF EXISTS Xe;
GO
CREATE TABLE Khach_Hang(
    MaKH     VARCHAR(10)   NOT NULL PRIMARY KEY,
    TenKH    NVARCHAR(50)  NOT NULL,
    CMND     VARCHAR(12)   NOT NULL UNIQUE CHECK (LEN(CMND) = 12 AND CMND NOT LIKE '%[^0-9]%'),
    GioiTinh NVARCHAR(10)  NOT NULL CHECK (GioiTinh IN (N'Nam', N'Nữ')),
    DiaChi   NVARCHAR(50)  NULL
);
CREATE TABLE Xe(
    MaXe     VARCHAR(10)   NOT NULL PRIMARY KEY,
    TenXe    NVARCHAR(50)  NOT NULL,
    DungTich INT           NOT NULL CHECK (DungTich > 0),
    DonGia   INT           NOT NULL CHECK (DonGia >= 0)
);
CREATE TABLE Mua_Xe(
    MaKH     VARCHAR(10)   NOT NULL,
    MaXe     VARCHAR(10)   NOT NULL,
    NgayMua  DATE          NOT NULL,
    SoLuong  INT           NOT NULL CHECK (SoLuong > 0),
    GhiChu   NVARCHAR(100) NULL,
    CONSTRAINT PK_Mua_Xe PRIMARY KEY (MaKH, MaXe, NgayMua),
    CONSTRAINT FK_MuaXe_KH FOREIGN KEY (MaKH) REFERENCES Khach_Hang(MaKH),
    CONSTRAINT FK_MuaXe_Xe FOREIGN KEY (MaXe) REFERENCES Xe(MaXe) ON DELETE CASCADE
);
GO
-- Dữ liệu mẫu
INSERT INTO Xe VALUES ('XE01',N'Suzuki X-Bike',125,21500000),('XE02',N'Honda Wave',110,18000000),
                      ('XE03',N'Yamaha Exciter',150,47000000),('XE04',N'Towner',100,15000000);
INSERT INTO Khach_Hang VALUES ('KH01',N'Nguyễn Văn Sơn','079201001234',N'Nam',N'Q1, TP.HCM'),
                              ('KH02',N'Trần Thị Lan','079201001235',N'Nữ',N'Q3, TP.HCM'),
                              ('KH03',N'Lê Minh Tuấn','079201001236',N'Nam',N'Thủ Đức');
INSERT INTO Mua_Xe VALUES ('KH01','XE01','2011-10-28',1,NULL),('KH02','XE01','2012-10-29',3,NULL),('KH03','XE02','2012-10-28',1,N'Laptop');
GO
